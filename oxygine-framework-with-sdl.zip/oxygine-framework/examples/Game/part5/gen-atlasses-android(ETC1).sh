#!/usr/bin/env sh
./../../../tools/oxyresbuild -x xmls/ui.xml --src_data data --dest_data data --compress etc1
