package org.oxygine.HelloWorld;

import org.oxygine.lib.OxygineActivity;

public class MainActivity extends OxygineActivity
{

}
